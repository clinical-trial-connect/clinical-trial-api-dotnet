﻿namespace TestingGraphql
{
    public class ClinicalFilter
    {
        public string search { get; set; }
        public int first { get; set; }
        public string after { get; set; }
    }
}