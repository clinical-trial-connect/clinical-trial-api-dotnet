﻿namespace TestingGraphql
{
    public class ClinicalCondition
    {
        public string Name { get; set; }
    }
}