﻿namespace TestingGraphql
{
    public class ClinicalSponsor
    {
        public string Name { get; set; }
    }
}